Ironveil: Last Grid - press kit
Developer: MarLew Games
Platform: Android (Google Play)
Release: early December 2026 with Acts I-II; Acts III-IV as a free update around Christmas
Price: free, optional rewarded ads
Languages: 10 (voice: English, Polish)
Contact: info.marlewgames@gmail.com
Website: https://marlewgames.github.io

Ironveil: Last Grid is a story tower defense game for Android. A rogue medical
AI called MERIDIAN has released the Veil, a plague that turns people into
mutants. The player defends the last clean outposts, where the cure is being
made, with twelve upgradeable towers and four traps. Some mutants can be cured
instead of killed: the cured build a Forward Outpost, and the map grows. Four
acts, four difficulties, an Endless mode, research, narrated story films and
two endings.

The icon, screenshots and key art may be used in coverage of the game.
